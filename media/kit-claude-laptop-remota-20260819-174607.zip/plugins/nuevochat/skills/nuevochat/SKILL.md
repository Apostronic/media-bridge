---
description: Configura el modelo y el esfuerzo óptimos de un chat, y explica la escalera de esfuerzo (high / xhigh / ultracode / ultrathink). Activar cuando el usuario dice "configura el chat", "nuevochat", "qué modelo uso", "qué modelo necesito para X", "cómo arranco este chat", "optimiza los tokens", "qué esfuerzo uso", "cuándo uso ultracode", "para qué sirve xhigh" o pide orientación sobre configuración de modelo, esfuerzo o sub-agentes.
---

Objetivo: dejar el chat configurado (modelo, esfuerzo, sub-agentes, higiene) o responder una consulta sobre esa configuración. Sin prosa extra. Estación de trabajo: la pestaña **Code** de la app de escritorio (Cowork quedó cerrado el 2026-07-28; no referirse a él).

**Elige la vía antes de responder:**

- **Vía A — CONSULTA** (el usuario pregunta *qué* usar o *para qué sirve* algo: "¿cuándo uso ultracode?", "¿xhigh sirve de algo?", "¿qué modelo para X?"): NO hagas las 3 preguntas. Responde directo con las tablas de referencia de abajo, aplicadas a lo que preguntó.
- **Vía B — CONFIGURACIÓN** (el usuario abre un chat y quiere dejarlo listo): sigue los Pasos 1-3.
- **Vía rápida:** si al invocar ya dio respuestas ("nuevochat mecanica corta", "estandar larga", "diagnostico"), tómalas como dadas y no las repreguntes. Pregunta solo lo que falte.

---

## Referencia 1 — Modelo según la tarea

| Tarea | Modelo | Comando |
|---|---|---|
| Mecánica/repetitiva (renombrar, mover, extraer, clasificar, aplicar cambios ya definidos) | Haiku 4.5 | `/model claude-haiku-4-5-20251001` |
| Ejecución estándar — la mayoría (marketing, redacción, código, análisis habitual) | Sonnet 5 | `/model claude-sonnet-5` |
| Diagnóstico complejo (debugging enredado, arquitectura, auditoría, decisiones de riesgo) | Fable 5 | `/model claude-fable-5` — plan B si no está disponible por tope semanal: `/model claude-opus-5` |

Regla de volumen: más de 10 elementos a procesar uno por uno → delegar a un sub-agente `model: haiku` en vez de cambiar el modelo de la sesión.

## Referencia 2 — La escalera de esfuerzo

| Nivel | Qué es | Cuándo |
|---|---|---|
| low / medium | Corto y rápido / ahorra tokens | Ignorar. Para lo mecánico la palanca correcta es cambiar a Haiku, no bajar el esfuerzo de un modelo caro |
| **high** | Balance. Default de casi todos los modelos | El piso normal. La mayoría del trabajo |
| **xhigh** | Razonamiento profundo | Cuando la tarea exige pensar duro pero NO un enjambre de agentes: diagnóstico, arquitectura, auditoría de una pieza. `/effort xhigh` |
| max | Sin tope de gasto | No usar: rendimientos decrecientes y riesgo de sobrepensar |
| **ultracode** | NO es un nivel del modelo: es xhigh MÁS workflows multiagente automáticos en cada tarea sustantiva | Solo auditorías, migraciones, barridos masivos o revisión adversaria de algo crítico. ~cientos de miles de tokens por pedido y consume el límite semanal de workflows, que es escaso. `/effort ultracode` para una sesión entera (BAJARLO al terminar) o el prefijo `ultracode:` para un solo pedido |

**`ultrathink`**: palabra escrita dentro del prompt que activa razonamiento más profundo SOLO en ese turno, sin tocar la configuración de la sesión. Ideal para una pregunta difícil suelta dentro de un chat normal. "piensa bien" y "think hard" NO son palabras clave.

La escala está calibrada POR modelo: "Alto" en Sonnet no gasta lo mismo que "Alto" en Opus.

## Referencia 3 — Dónde se cambia

Modelo y esfuerzo se ven y se cambian **abajo a la derecha de la caja de texto**, y se pueden cambiar mensaje a mensaje. También con `/model` y `/effort`; el rastro que deja la app es idéntico por ambas vías.

`[1m]` contexto extendido: en Code es una opción al elegir el modelo. No activarlo por defecto — una ventana enorme invita a no cortar la sesión, y el historial largo se re-paga en cada turno. Activarlo solo si la sesión va a cargar material masivo de verdad.

---

## Vía B — Pasos

**Paso 1 — Lanza AskUserQuestion con las preguntas que falten (de estas 3):**

P1 (header "Tipo de tarea"):
- Mecánica/repetitiva — renombrar, mover, scrapear, aplicar cambios ya definidos
- Ejecución estándar — marketing, redacción, código, análisis habitual (la mayoría)
- Diagnóstico complejo — debugging enredado, arquitectura, decisiones de riesgo

P2 (header "Duración"):
- Corta (~30 min, una tarea concreta)
- Media (1-2 h, varias tareas relacionadas)
- Larga (toda la tarde o más, puede crecer)

P3 (header "Sub-agentes / multimedia"):
- No — chat lineal sin delegación ni snapshots frecuentes
- Sí, puntual — 1-2 sub-agentes o snapshots ocasionales
- Sí, intensivo — múltiples sub-agentes o multimedia pesada frecuente

Si mencionó un proyecto específico al invocar (ej. "nuevochat para mowi"), úsalo para armar el prompt de arranque.

**Paso 2 — Decisión:** modelo por la Referencia 1; esfuerzo por la Referencia 2 (mecánica y estándar → high; diagnóstico complejo → xhigh; ultracode solo si el trabajo es de barrido/auditoría masiva).

Sub-agentes por tipo de delegación:
- Extracción / scraping / lectura de docs → haiku
- Research iterativo / análisis medio → sonnet
- Síntesis y decisiones → heredar el modelo principal
- Sin sub-agentes previstos → indicarlo explícito

Higiene de sesión (en Code existe `/handoff` para traspasar a una sesión fresca):
- Corta → al terminar, sesión nueva (opcional)
- Media → sesión nueva al cerrar el primer bloque de trabajo
- Larga → `/handoff` y sesión nueva cada ~90 min o al cambiar de tema; nunca reutilizar para una tarea distinta

Multimedia/UI pesada (si aplica):
- Puntual: 1 snapshot cada 5-10 acciones; encadenar clicks por id de elemento; usar `get_page_text`/`find` antes que screenshot.
- Intensivo: bloques de >10 acciones de UI → delegar SIEMPRE a un sub-agente (los volcados pesados mueren en su contexto); dentro del sub-agente, 1 snapshot cada 5-10 acciones.

**Paso 3 — Devuelve solo este bloque (español neutro LATAM con tuteo, sin prosa adicional):**

**Modelo:** [nombre] — [justificación en ≤10 palabras] · [comando] · si es Fable 5, añade: "plan B: `/model claude-opus-5` si no está disponible"
**Esfuerzo:** [high / xhigh / ultracode] — [comando y por qué]
**[1m]:** [sí/no + motivo en ≤8 palabras]

**Sub-agentes:**
- [tipo de delegación] → [modelo]
- Ninguno previsto (si no hay)

**Higiene:** [cuándo cortar con /handoff y sesión nueva]
**Multimedia/UI:** [regla aplicable | No aplica]

**Prompt de arranque:**
> [1-2 oraciones que dejan el chat enfocado desde el turno 1; incluir el proyecto/área si lo mencionó]

→ Cambia modelo y esfuerzo abajo a la derecha antes del primer mensaje; usa este prompt como tu próximo mensaje de trabajo.
No repetir esta configuración en respuestas posteriores del mismo chat.
