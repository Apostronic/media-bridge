# nuevochat

Configura el modelo y el esfuerzo óptimos de un chat, y explica la escalera de esfuerzo.

## Cómo usarlo

Tiene dos vías. La skill elige sola según lo que preguntes.

**Vía consulta** — respondes una duda, sin cuestionario:

- "qué modelo uso para [tarea]"
- "cuándo uso ultracode"
- "para qué sirve xhigh"
- "qué esfuerzo me conviene"

**Vía configuración** — dejar un chat listo antes del primer mensaje:

- "configura el chat"
- "nuevochat"
- "cómo arranco este chat"
- "optimiza los tokens de este chat"

Hace 3 preguntas rápidas (tipo de tarea, duración, sub-agentes) y devuelve el modelo, el esfuerzo, el plan de sub-agentes, cuándo cortar la sesión y un prompt de arranque.

## Lógica de modelo

| Tipo de tarea | Modelo | Cuándo |
|---|---|---|
| Mecánica/repetitiva | Haiku 4.5 (`claude-haiku-4-5-20251001`) | Renombrar, mover, scrapear, aplicar cambios definidos |
| Estándar (la mayoría) | Sonnet 5 (`claude-sonnet-5`) | Marketing, redacción, código, análisis habitual |
| Diagnóstico complejo | Fable 5 (`claude-fable-5`), plan B Opus 5 (`claude-opus-5`) | Debugging enredado, arquitectura, decisiones de riesgo |

## Escalera de esfuerzo

| Nivel | Qué es | Cuándo |
|---|---|---|
| low / medium | Rápido / ahorra tokens | Ignorar: para lo mecánico la palanca es cambiar a Haiku |
| high | Default de casi todos los modelos | El piso. La mayoría del trabajo |
| xhigh | Razonamiento profundo | Pensar duro sin enjambre de agentes |
| max | Sin tope de gasto | No usar: rendimientos decrecientes |
| ultracode | xhigh + workflows multiagente automáticos | Solo auditorías, migraciones, barridos masivos. Consume el límite semanal de workflows |

`ultrathink` dentro del prompt = razonamiento profundo solo en ese turno, sin tocar la sesión.

## Filosofía

"Fable para pensar, Sonnet para ejecutar, Haiku para extraer. El ahorro grande está en cortar la sesión a tiempo."

## Mantenimiento (fuente canónica de modelos)

Las tablas de arriba son la fuente canónica. Si cambia un modelo o el plan B, sincronizar a mano estos lugares, que no se enteran solos:

- `plugins/nuevochat/skills/nuevochat/SKILL.md` — la skill (después de editar: bump de versión + `setup\sync-plugins.ps1`, según `setup\GUIA-ACTUALIZAR-PLUGINS-SKILLS.md`).
- `~/.claude/commands/handoff.md` — recomendación de modelo del traspaso.
- `~/.claude/commands/retomar.md` — chequeo de modelo al retomar.
- `Documents/Claude/CLAUDE.md` — campo Modelo del sello de tarea.

Regla actual del modelo para diagnóstico complejo: **Fable 5** primario, **Opus 5** (`claude-opus-5`, mismo costo que Opus 4.8 y mejor modelo — decisión 2026-07-28) como plan B cuando Fable 5 no esté disponible.

Nota: el comando `~/.claude/commands/nuevochat.md` ya NO existe (se archivó el 2026-07-09 por duplicar la skill). La skill es la única vía.
