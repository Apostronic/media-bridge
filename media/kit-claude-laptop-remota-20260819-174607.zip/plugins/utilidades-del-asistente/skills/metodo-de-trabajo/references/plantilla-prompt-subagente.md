# Plantilla de prompt de sub-agente

Estructura fija de 6 secciones. Llena los huecos `<...>`, borra lo que no aplique, y pega
al final el bloque de `bloque-inyeccion.md` (con la línea de dosis según el modelo).

La regla que gobierna todo: **el sub-agente no ve la conversación**. Si un dato no está en
el prompt, para el agente no existe — y un agente sin datos no pregunta: inventa.

---

## Plantilla

```
## CONTEXTO
<Qué es el proyecto y qué se está haciendo, en 2-4 frases. Decisiones previas que
condicionan el trabajo. Rutas SIEMPRE absolutas.>

## TAREA
<Qué debe hacer, paso a paso si hay orden obligatorio. Una tarea por agente: si
necesitas dos cosas independientes, son dos agentes.>

## CRITERIO DE ÉXITO
<Cómo se ve el trabajo terminado y bien hecho — qué archivo existe, qué dato quedó
extraído, qué condición se cumple. Si no puedes escribir esto, la tarea no está lista
para delegarse.>

## LÍMITES
- No toques: <archivos/carpetas/sistemas fuera del alcance>
- No instales ni configures: <salvo lo listado>
- Ríndete y reporta si: <condición de rendición — p. ej. "el sitio pide login",
  "el archivo no existe", "llevas más de N intentos">

## FORMATO DE SALIDA
<Estructura exacta del retorno: lista, tabla, JSON, campos. Pide rutas absolutas,
medidas y veredictos — nunca "un resumen". Ejemplo mínimo si el formato importa.>

## MÉTODO
<Pegar aquí, textual, el bloque de bloque-inyeccion.md + la línea de dosis por modelo
+ el extra visual si aplica.>
```

---

## Ejemplo lleno (delegación real a Haiku)

```
## CONTEXTO
Workspace del usuario en C:\Users\<usuario>\Documents\Claude. Estamos auditando qué
archivos de proyectos\ejemplo\documentos\ mencionan la campaña "Lanzamiento X". Ya se
decidió: solo lectura, no se mueve ni edita nada.

## TAREA
1. Lista los .md y .docx de C:\Users\<usuario>\Documents\Claude\proyectos\ejemplo\documentos\
2. En cada uno busca menciones de "Lanzamiento X" (insensible a mayúsculas).
3. Para cada match: archivo, línea aproximada y la frase completa donde aparece.

## CRITERIO DE ÉXITO
Una tabla con TODOS los archivos revisados (incluidos los que no tienen matches, marcados
"sin menciones") — que ningún archivo quede sin revisar es más importante que la velocidad.

## LÍMITES
- No toques nada fuera de esa carpeta; solo lectura en todo momento.
- Ríndete y reporta si un .docx no se puede leer como texto: márcalo "ILEGIBLE" y sigue.

## FORMATO DE SALIDA
Tabla: ruta absoluta | n.º de menciones | frases textuales (o "sin menciones" / "ILEGIBLE").
Al final una línea: "Revisados: N de M archivos".

## MÉTODO
--- MÉTODO DE TRABAJO (obligatorio, no negociable) ---
<...bloque completo de bloque-inyeccion.md...>
10. LITERAL. Ejecuta exactamente lo indicado, sin optimizaciones ni atajos propios. Tu
    valor es velocidad y obediencia, no criterio.
--- FIN DEL MÉTODO ---
```

---

## Errores frecuentes al delegar (y su antídoto)

| Error | Antídoto |
|---|---|
| "Revisa los archivos del proyecto" (¿cuáles? ¿dónde?) | Rutas absolutas y lista explícita o patrón de búsqueda |
| Pedir "un resumen" | Definir campos exactos del retorno |
| Sin condición de rendición | El agente insiste 20 veces o inventa; escríbele una salida digna |
| Prompt sin criterio de éxito | El agente decide solo cuándo "terminó" — y termina temprano |
| Dos tareas independientes en un agente | Dos agentes: se paralelizan y un fallo no arrastra al otro |
| Confiar en que "ya sabe" las reglas del workspace | Solo sabe lo que va en el prompt: por eso el bloque va SIEMPRE |
