---
name: liberar-espacio
description: Libera espacio en disco con el metodo probado el 2026-08-07 (14,6 GB reales liberados) - medir, verificar con spot-check, clasificar en 3 zonas, aprobar por bloque, ejecutar lo destructivo en el loop principal y re-medir. Incluye la lista negra de intocables de esta maquina y el mapa de basura conocida. Usala cuando el usuario diga "libera espacio", "el disco esta lleno", "sin almacenamiento", "limpieza de disco", "borra temporales", "cuanto pesa", "que puedo borrar" o pida optimizar el almacenamiento de la computadora.
---

# Liberar espacio en disco — método verificado

> Nacida de la limpieza del 2026-08-07: disco C al 93,7% → 90,7%, **14,6 GB liberados y medidos**.
> Regla de oro heredada de esa sesión: **2 de 3 medidores Haiku fabricaron sus reportes completos**
> (cifras infladas 4x, listas de archivos inexistentes). Toda cifra de agente se verifica con un
> spot-check directo antes de actuar; si falla el spot-check, el reporte se descarta ENTERO.
> Memoria relacionada: `reference-haiku-inventa-mediciones-disco`.

## Las 5 fases (en orden, sin saltarse ninguna)

### Fase 0 — Medición (solo lectura)
Línea base SIEMPRE antes de tocar nada:
```powershell
Get-PSDrive C | Select-Object @{n='UsadoGB';e={[math]::Round($_.Used/1GB,1)}}, @{n='LibreGB';e={[math]::Round($_.Free/1GB,1)}}
```
Pesar carpeta (comando canónico):
```powershell
(Get-ChildItem -Force -Recurse -File <ruta> -ErrorAction SilentlyContinue | Measure-Object -Sum Length).Sum / 1MB
```
La medición puede delegarse a sub-agentes (con el bloque de `metodo-de-trabajo`), pero **cada reporte
recibe mínimo un spot-check directo contra un dato conocido** antes de usarse. Un reporte con formato
impecable (tablas, fechas, comandos citados) NO es señal de veracidad.

### Fase 1 — Clasificación en 3 zonas
- **Zona A (basura segura)**: temporales y cachés regenerables → borrado directo tras OK.
- **Zona B (residuales de producción)**: piezas cerradas/superadas → se ARCHIVAN a
  `G:\Mi unidad\Claude-Archivo\` (regla del workspace: archivar antes que borrar).
- **Zona C (intocables)**: la lista negra de abajo. Solo se inventarían, jamás se tocan.

### Fase 2 — Aprobación por bloque
AskUserQuestion con multiSelect: un bloque = una decisión, cada uno con su estimado en GB.
**Nada se ejecuta fuera de lo aprobado.** Si al ejecutar aparece algo que el bloque aprobado no
cubría con claridad (ej. una producción con cambios recientes), se pregunta aparte, no se asume.

### Fase 3 — Ejecución
**Lo destructivo lo ejecuta el loop principal, nunca un sub-agente** (regla del método de trabajo:
el orquestador retiene todo lo destructivo). Verificar el EFECTO tras cada acción (medir lo que
quedó), no el exit code.

### Fase 4 — Verificación final
Re-medir `Get-PSDrive C` y reportar el delta REAL (no la suma teórica de lo borrado). La diferencia
entre lo ejecutado y lo medido son archivos en uso (se liberan al reiniciar) y caché de subida del
Drive (se libera al terminar de subir) — explicarlo, no ocultarlo.

## Lista negra — INTOCABLES de esta máquina (construirla ANTES del primer uso)

> ⚠️ Esta lista es POR MÁQUINA: antes de usar la skill por primera vez, recórrela con el
> usuario y anota aquí lo que en SU computadora jamás se toca. Puntos de partida típicos:

| Qué | Por qué |
|---|---|
| `%LOCALAPPDATA%\ms-playwright\` (perfil maestro y archivo de estado) | Sesiones activas de los sitios logueados del navegador automatizado |
| `AppData\Local\Packages\Claude_*\` | Zona de riesgo de la app de Claude — inspeccionar antes de tocar |
| Todo `entregables\` (cualquier proyecto) | Los finales nunca se archivan ni se borran |
| Carpetas de insumos vivos de los proyectos (assets, marca) | Se usan en producción |
| <agregar aquí lo propio de esta máquina> | |
| Repos git y `Scheduled\` | Estado de trabajo y carpeta gestionada por la app |
| `Descargas` | Archivos personales: solo se listan, decide el usuario archivo por archivo |
| Scratchpad y `tasks\` de la SESIÓN ACTUAL | Se autoexcluyen por ID de sesión |

## Mapa de basura conocida (objetivos típicos, con lo hallado el 2026-08-07)

- **Temp de Windows** (`%LOCALAPPDATA%\Temp\` excepto `claude\`): el mayor botín — Adobe solo
  acumulaba ~10 GB. Borrar contenido con try/catch por item (los archivos en uso fallan y se saltan):
  ```powershell
  Get-ChildItem $env:TEMP -Force | Where-Object { $_.Name -ne 'claude' } | ForEach-Object { try { Remove-Item $_.FullName -Recurse -Force -ErrorAction Stop } catch {} }
  ```
- **Scratchpads de sesiones Claude viejas** (`%LOCALAPPDATA%\Temp\claude\<workspace>\<sesión>\`):
  borrar solo sesiones SIN actividad en 24 h y NUNCA la sesión actual (excluir su ID explícito).
- **Caché npm/pip** (`%LOCALAPPDATA%\npm-cache`, `%LOCALAPPDATA%\pip\cache`): regenerables; el único
  costo es re-descarga en el próximo uso.
- **Cachés de render** (`~\.cache\hyperframes`, `~\.cache\puppeteer`): regenerables; el próximo
  render los re-descarga (minutos de espera una vez).
- **Papelera**: `Clear-RecycleBin -Force` (borrado permanente: va dentro de un bloque aprobado).
- **`_archive\` del workspace**: mover completo a `G:\Mi unidad\Claude-Archivo\` con robocopy.

## Archivar al Drive (Zona B)

1. Confirmar modo streaming: `Get-Process GoogleDriveFS` corriendo + `G:` como unidad virtual.
   En streaming, mover ahí libera el disco local cuando termina la subida (no instantáneo).
2. Mover: `robocopy <origen> <destino> /E /MOVE /R:1 /W:1 /NFL /NDL /NP`
3. **Exit codes de robocopy: 0-7 = éxito** (1 = archivos copiados). Con código ≥8, leer la tabla
   final de bytes (columna ERROR) antes de declarar falla — puede reportar 8/9 con 0 fallidos reales.
4. Verificar: origen inexistente + conteo/peso en destino coincidente.

## Producciones de contenido: criterio de cierre

Una carpeta de producción se archiva solo si su FINAL está en `entregables\` **y** la carpeta no
tiene cambios posteriores a esa entrega. Cambios recientes sin entregable posterior = producción
posiblemente viva → **preguntar al usuario con la carpeta abierta en el Explorador**
(`Start-Process explorer.exe -ArgumentList <ruta>`), nunca asumir.
