# -*- coding: utf-8 -*-
"""
Herramienta de corte de secciones (verbatim) para CLAUDE.md y archivos de contexto.
Ver instrucciones del orquestador (tarea 2026-08-07).

Reglas:
- Encoding: UTF-8 sin BOM, siempre.
- Preserva fin de línea original de cada línea (splitlines(keepends=True) respeta
  mezclas CRLF/LF si las hubiera; en la práctica cada archivo es uniforme).
- start_marker / end_marker deben aparecer como substring EXACTAMENTE UNA VEZ en
  el source (si no, aborta ese corte concreto y lo reporta PENDIENTE).
- Extrae desde la línea que contiene start_marker (inclusive) hasta la línea
  ANTERIOR a la que contiene end_marker (o EOF si end_marker es None).
- Verificación de cobertura tras cada archivo operado.
"""

import os
import shutil
from collections import Counter
from datetime import date

BACKUP_SUFFIX = ".bak-" + date.today().strftime("%Y%m%d")


# ---------------------------------------------------------------------------
# IO de bajo nivel
# ---------------------------------------------------------------------------

def read_text_preserve(path):
    """Lee un archivo como utf-8 (quita BOM si existe), preserva EOL originales."""
    with open(path, "rb") as f:
        raw = f.read()
    if raw.startswith(b"\xef\xbb\xbf"):
        raw = raw[3:]
    return raw.decode("utf-8")


def write_text_no_bom(path, text):
    with open(path, "wb") as f:
        f.write(text.encode("utf-8"))


def dominant_newline(text):
    if "\r\n" in text:
        return "\r\n"
    return "\n"


def normalize_newlines_to(s, nl):
    """Convierte los \\n literales de un string (típicamente escrito a mano en
    el prompt del orquestador) al estilo de fin de línea del archivo destino."""
    if nl == "\n":
        return s
    # normalizamos primero por si ya trae \r\n mezclado
    s = s.replace("\r\n", "\n")
    return s.replace("\n", nl)


def ensure_backup(path, backups_done, suffix=BACKUP_SUFFIX):
    if path in backups_done:
        return
    bak_path = path + suffix
    if not os.path.exists(bak_path):
        shutil.copyfile(path, bak_path)
    backups_done.add(path)


def kb(path):
    if not os.path.exists(path):
        return 0.0
    return round(os.path.getsize(path) / 1024.0, 2)


# ---------------------------------------------------------------------------
# Núcleo: cut()
# ---------------------------------------------------------------------------

def find_line_indices(lines, marker):
    return [i for i, l in enumerate(lines) if marker in l]


def cut(source_path, start_marker, end_marker, dest_path, dest_header, stub,
        backups_done, report, dest_initial_header=None, label=None):
    """
    Ejecuta un corte. Devuelve dict con detalle si tuvo éxito, o None si quedó
    PENDIENTE (y lo agrega a `report`).
    """
    label = label or f"{os.path.basename(source_path)} -> {os.path.basename(dest_path)}"

    if not os.path.exists(source_path):
        report.append({"status": "PENDIENTE", "label": label,
                        "reason": f"source no existe: {source_path}"})
        return None

    text = read_text_preserve(source_path)
    nl = dominant_newline(text)
    lines = text.splitlines(keepends=True)

    start_hits = find_line_indices(lines, start_marker)
    end_hits = find_line_indices(lines, end_marker) if end_marker is not None else []

    if len(start_hits) != 1:
        report.append({
            "status": "PENDIENTE", "label": label,
            "reason": f"start_marker apareció {len(start_hits)} veces (se esperaba 1): {start_marker!r}",
        })
        return None
    if end_marker is not None and len(end_hits) != 1:
        report.append({
            "status": "PENDIENTE", "label": label,
            "reason": f"end_marker apareció {len(end_hits)} veces (se esperaba 1): {end_marker!r}",
        })
        return None

    start_idx = start_hits[0]
    end_idx = end_hits[0] if end_marker is not None else len(lines)

    if end_idx <= start_idx:
        report.append({
            "status": "PENDIENTE", "label": label,
            "reason": "end_marker aparece antes o en la misma línea que start_marker",
        })
        return None

    extracted_lines = lines[start_idx:end_idx]
    extracted_text = "".join(extracted_lines)

    stub_norm = normalize_newlines_to(stub, nl)
    if stub_norm and not stub_norm.endswith(nl):
        stub_norm += nl

    new_lines = lines[:start_idx] + ([stub_norm] if stub_norm else []) + lines[end_idx:]
    new_source_text = "".join(new_lines)

    # Preparar dest (crearlo si hace falta)
    if not os.path.exists(dest_path):
        if dest_initial_header is None:
            raise ValueError(f"dest {dest_path} no existe y no se dio dest_initial_header")
        initial = normalize_newlines_to(dest_initial_header, nl)
        write_text_no_bom(dest_path, initial)

    dest_header_norm = normalize_newlines_to(dest_header, nl) if dest_header else ""
    dest_existing = read_text_preserve(dest_path)
    dest_new_text = dest_existing + dest_header_norm + extracted_text

    # Backup del source (solo la primera vez que se toca en esta corrida)
    ensure_backup(source_path, backups_done)

    write_text_no_bom(source_path, new_source_text)
    write_text_no_bom(dest_path, dest_new_text)

    return {
        "status": "OK",
        "label": label,
        "source": source_path,
        "dest": dest_path,
        "lines_moved": len(extracted_lines),
        "start_line_0idx": start_idx,
        "end_line_0idx_excl": end_idx,
        "extracted_text": extracted_text,
    }


def replace_literal(path, old, new, backups_done, report, label=None, must_be_unique=True):
    """Reemplazo de texto simple (no-corte) para líneas tipo 'Última actualización'."""
    label = label or os.path.basename(path)
    if not os.path.exists(path):
        report.append({"status": "PENDIENTE", "label": label, "reason": f"source no existe: {path}"})
        return None
    text = read_text_preserve(path)
    count = text.count(old)
    if must_be_unique and count != 1:
        report.append({"status": "PENDIENTE", "label": label,
                        "reason": f"'{old}' aparece {count} veces (se esperaba 1)"})
        return None
    if count == 0:
        report.append({"status": "PENDIENTE", "label": label, "reason": f"no se encontró: {old!r}"})
        return None
    ensure_backup(path, backups_done)
    new_text = text.replace(old, new, 1 if must_be_unique else -1)
    write_text_no_bom(path, new_text)
    return {"status": "OK", "label": label, "path": path}


# ---------------------------------------------------------------------------
# Verificación de cobertura
# ---------------------------------------------------------------------------

def _norm_lines(text):
    return [l.strip() for l in text.splitlines() if l.strip()]


def verify_coverage(original_text, final_source_text, dest_texts):
    """
    original_text: contenido ORIGINAL (backup) del source antes de cualquier corte.
    final_source_text: contenido final del source tras TODOS sus cortes.
    dest_texts: lista de contenidos finales de los dest tocados por cortes de este source.
    """
    orig_lines = _norm_lines(original_text)
    final_lines = _norm_lines(final_source_text)
    dest_lines_all = []
    for dt in dest_texts:
        dest_lines_all += _norm_lines(dt)

    orig_counter = Counter(orig_lines)
    final_counter = Counter(final_lines)
    dest_counter = Counter(dest_lines_all)

    missing = []
    for l, cnt in orig_counter.items():
        total_found = final_counter.get(l, 0) + dest_counter.get(l, 0)
        if total_found <= 0:
            missing.append(l)

    duplicated = []
    for l, cnt in final_counter.items():
        orig_cnt = orig_counter.get(l, 0)
        if orig_cnt > 0 and cnt > orig_cnt:
            duplicated.append((l, orig_cnt, cnt))

    return {
        "total_lines_original": len(orig_lines),
        "found": len(orig_lines) - len(missing),
        "missing": missing,
        "duplicated": duplicated,
    }


# ---------------------------------------------------------------------------
# AUTO-TEST
# ---------------------------------------------------------------------------

def auto_test(scratch_dir):
    toy_path = os.path.join(scratch_dir, "_autotest_toy.md")
    dest_path = os.path.join(scratch_dir, "_autotest_dest.md")
    for p in (toy_path, dest_path, toy_path + BACKUP_SUFFIX):
        if os.path.exists(p):
            os.remove(p)

    toy_content = (
        "SECCION A\r\n"
        "linea a1\r\n"
        "linea a2\r\n"
        "\r\n"
        "SECCION B\r\n"
        "linea b1\r\n"
        "linea b2\r\n"
        "\r\n"
        "SECCION C\r\n"
        "linea c1\r\n"
        "linea c2\r\n"
    )
    write_text_no_bom(toy_path, toy_content)
    original_backup_ref = toy_content  # lo que debería quedar en el .bak

    backups_done = set()
    report = []

    result = cut(
        source_path=toy_path,
        start_marker="SECCION B",
        end_marker="SECCION C",
        dest_path=dest_path,
        dest_header="\n## Movido en autotest\n\n",
        stub="SECCION B -- MOVIDA (autotest)\n",
        backups_done=backups_done,
        report=report,
        dest_initial_header="# Dest autotest\n\n",
        label="autotest-cut-B",
    )

    ok = True
    problems = []

    if result is None:
        ok = False
        problems.append(f"cut() devolvió None inesperadamente: {report}")

    # Verificar backup creado y con el contenido original
    bak_path = toy_path + BACKUP_SUFFIX
    if not os.path.exists(bak_path):
        ok = False
        problems.append("no se creó el backup del toy file")
    else:
        bak_content = read_text_preserve(bak_path)
        if bak_content != original_backup_ref:
            ok = False
            problems.append("el backup no coincide byte a byte con el original")

    final_source = read_text_preserve(toy_path)
    final_dest = read_text_preserve(dest_path)

    if "SECCION B -- MOVIDA (autotest)" not in final_source:
        ok = False
        problems.append("el stub no quedó en el source")
    if "linea b1" in final_source or "linea b2" in final_source:
        ok = False
        problems.append("el contenido de SECCION B sigue en el source (no se removió)")
    if "SECCION A" not in final_source or "SECCION C" not in final_source:
        ok = False
        problems.append("SECCION A o SECCION C se perdieron del source (no debían tocarse)")
    if "linea b1" not in final_dest or "linea b2" not in final_dest:
        ok = False
        problems.append("el contenido de SECCION B no llegó al dest")
    if "## Movido en autotest" not in final_dest:
        ok = False
        problems.append("el dest_header no se escribió en el dest")

    # Verificar preservación de CRLF
    if "\r\n" not in final_source:
        ok = False
        problems.append("no se preservó CRLF en el source final")

    # Verificación de cobertura
    cov = verify_coverage(original_backup_ref, final_source, [final_dest])
    if cov["missing"]:
        ok = False
        problems.append(f"cobertura: líneas perdidas en autotest: {cov['missing']}")
    if cov["found"] != cov["total_lines_original"]:
        ok = False
        problems.append("cobertura: found != total en autotest")

    # Test de marcador NO único -> debe abortar como PENDIENTE
    toy2_path = os.path.join(scratch_dir, "_autotest_toy2.md")
    write_text_no_bom(toy2_path, "X\nSECCION B\nY\nSECCION B\nZ\nSECCION C\nW\n")
    report2 = []
    result2 = cut(
        source_path=toy2_path,
        start_marker="SECCION B",
        end_marker="SECCION C",
        dest_path=dest_path,
        dest_header="",
        stub="stub\n",
        backups_done=set(),
        report=report2,
        label="autotest-cut-duplicado",
    )
    if result2 is not None:
        ok = False
        problems.append("cut() debería haber abortado con marker duplicado y no lo hizo")
    if not report2 or report2[0]["status"] != "PENDIENTE":
        ok = False
        problems.append("cut() con marker duplicado no reportó PENDIENTE")
    # el toy2 no debe haber sido tocado
    toy2_after = read_text_preserve(toy2_path)
    if toy2_after != "X\nSECCION B\nY\nSECCION B\nZ\nSECCION C\nW\n":
        ok = False
        problems.append("cut() modificó el source pese a abortar por marker duplicado")

    return ok, problems, report


if __name__ == "__main__":
    import sys
    scratch = os.path.dirname(os.path.abspath(__file__))
    ok, problems, report = auto_test(scratch)
    print("=== AUTO-TEST ===")
    print("OK" if ok else "FALLÓ")
    if problems:
        for p in problems:
            print(" - PROBLEMA:", p)
    if report:
        print(" - report:", report)
    sys.exit(0 if ok else 1)
