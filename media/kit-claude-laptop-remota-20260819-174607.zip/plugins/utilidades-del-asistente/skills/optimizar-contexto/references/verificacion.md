# Verificación de la mudanza — protocolo del fiscal adversario

> Se usa en la Fase 3.3 de la skill. El fiscal DEBE ser un sub-agente fresco (sin contexto
> de la conversación): su ignorancia es el test. Modelo recomendado: Sonnet.

## Cómo armar las preguntas (las escribe el orquestador, no el fiscal)

- **8-10 preguntas sobre conocimiento MOVIDO**: cada una debe ser respondible partiendo
  SOLO del archivo aligerado y siguiendo únicamente sus talones. Cubre todos los archivos
  operados; pide datos concretos (fechas, causas raíz, listas, rutas), no generalidades.
- **2 preguntas de CONTROL sobre contenido NO movido**: deben responderse sin saltar a
  ningún destino. Detectan si la cirugía dañó lo que debía quedarse.

## Plantilla del prompt del fiscal

```
ROL: Fiscal adversario. Hoy (<fecha>) se movieron secciones de <N> archivos de contexto a
archivos on-demand nuevos, dejando talones. Tu misión es intentar demostrar que la mudanza
ROMPIÓ algo: conocimiento inaccesible, talones que prometen lo que el destino no contiene,
o punteros huérfanos. No participaste en la mudanza — tu ignorancia es el test. Ante la
duda, falla el punto (criterio fiscal, no benevolente).

ARCHIVOS ALIGERADOS (tu ÚNICO punto de partida; a otros archivos solo llegas siguiendo
los punteros/talones que encuentres dentro de ellos):
<lista de rutas absolutas>

PROHIBIDO: leer cualquier archivo *.bak* (invalidaría el test); modificar archivos.

PARTE A — <N> PREGUNTAS. Por pregunta: RESPONDIBLE (sí/no), respuesta en 1-2 frases, y la
cadena de salto (archivo aligerado → talón → destino → sección).
<preguntas numeradas, controles marcados como CONTROL>

PARTE B — AUDITORÍA DE TALONES. Por cada talón fechado <fecha>: (a) ¿el destino existe en
la ruta prometida?; (b) ¿contiene REALMENTE lo que el talón promete?; (c) ¿el talón dice
CUÁNDO leerlo? Veredicto: CUMPLE / SOBREPROMETE / SUBPROMETE.

PARTE C — PUNTEROS HUÉRFANOS. En los aligerados Y en los destinos visitados: extrae toda
referencia a rutas .md y verifica que existan en disco (ignora _archive\ y rutas históricas).

VEREDICTO FINAL: "MUDANZA ÍNTEGRA" solo si todas las preguntas son respondibles y hay 0
roturas CAUSADAS por la mudanza. Distingue SIEMPRE roturas causadas vs PREEXISTENTES.
```

Al prompt se le pega al final el bloque de método de
`utilidades-del-asistente:metodo-de-trabajo` (references/bloque-inyeccion.md) con la dosis
Sonnet, igual que a todo sub-agente.

## Qué hacer con el veredicto

- **Roturas causadas por la mudanza** → se corrigen de inmediato y se re-verifica el punto
  corregido (no hace falta re-correr el fiscal entero por un fix puntual y verificable).
- **Roturas preexistentes** → lista aparte para el usuario con ruta+línea; corregirlas
  requiere su OK. Regla al corregirlas: rutas muertas se actualizan a las reales; las
  referencias a archivos que ya no existen se MARCAN como históricas, nunca se borra la línea.
- **Talón SUBPROMETE por faltar el "cuándo leerlo"** → fue el fallo real de la corrida de
  producción 2026-08-07: los 3 elementos del talón son obligatorios.

## Historial de corridas de producción (credencial del método)

1. Histórico del CLAUDE.md del workspace → `auditorias/historico-claude-md-*.md` (2026-05/07).
2. MOWI-MEMORIA §10/§10bis/§10ter → `proyectos/mowi/contexto/MOWI-WEB-QUIRKS.md`
   (2026-08-07, commit 9efd1be del repo mowi-contexto-compartido).
3. Optimización general fuera de Mowi (2026-08-07): ~24 KB movidos en 7 archivos, 0 líneas
   perdidas, fiscal 12/12, 1 rotura causada (talón incompleto) corregida en el momento.
