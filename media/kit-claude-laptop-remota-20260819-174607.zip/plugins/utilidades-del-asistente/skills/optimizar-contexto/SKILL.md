---
name: optimizar-contexto
description: Optimiza los archivos de contexto siempre-cargados (CLAUDE.md, *-MEMORIA.md, *-CONTEXTO.md) moviendo secciones que solo sirven bajo demanda a archivos on-demand con talón, sin perder una sola línea — censo con KB por candidata, cirugía por script de marcadores, y verificación en 3 capas (cobertura mecánica, punteros, fiscal adversario). Usa esta skill SIEMPRE que el usuario pida "optimizar el contexto", "aligerar el CLAUDE.md", "mover secciones a on-demand", "reducir tokens del contexto siempre cargado", "el CLAUDE.md pesa mucho", "poner X bajo demanda con talón", o cualquier auditoría de qué contexto se carga en cada sesión y sobra. Método probado 3 veces en producción (histórico del CLAUDE.md, MOWI-WEB-QUIRKS, optimización general 2026-08-07). NO es para borrar contenido obsoleto (eso se reporta, no se corta) ni para resumir/reescribir archivos.
---

# Optimizar contexto — mover secciones a on-demand sin perder nada

El contexto siempre-cargado es un impuesto que se paga en CADA sesión. Esta skill lo reduce
con una regla sagrada: **el conocimiento cambia de casa, jamás se evapora**. Todo corte es
textual (cero resúmenes, cero reescrituras) y deja un talón que dice qué se movió, a dónde
y cuándo leerlo.

**Reparto de roles**: si la sesión corre en Fable/Opus, dirige y delega la ejecución
(censo de archivos no vistos, cirugía, fiscal) a sub-agentes Sonnet con el bloque de
`utilidades-del-asistente:metodo-de-trabajo`; la clasificación de candidatas, los stubs y
la síntesis son del orquestador. En Sonnet, ejecuta directo y delega solo el fiscal
(que DEBE ser un agente fresco sin contexto de la conversación).

## Fase 1 — Censo (sin tocar nada)

1. **Mide en KB** los archivos siempre-cargados y los cargados por trigger. Por sección:
   `awk '/^## |^### /{if(name)printf "%6.1f KB  %s\n", bytes/1024, name; name=$0; bytes=0} {bytes+=length($0)+1} END{if(name)printf "%6.1f KB  %s\n", bytes/1024, name}' archivo.md`
2. **Clasifica cada archivo por ROL**: auto-cargado (CLAUDE.md de carpeta) / cargado por
   trigger (*-MEMORIA, *-CONTEXTO) / ya on-demand / entregable. Detecta **cargas forzadas**
   (archivos que ordenan leer SIEMPRE otros archivos): ese peso encadenado cuenta.
3. **Criterio de candidata**: contenido que solo aplica bajo un trigger concreto (un canal,
   una herramienta, un flujo, una re-auditoría) y cuya ausencia no cambia el comportamiento
   de una sesión típica. La prueba clave: **regla operativa vs narrativa de justificación**.
   La regla se queda SIEMPRE; la historia que la justifica (casos de origen, crónicas de
   pruebas, postmortems embebidos) es candidata. Si un bloque MEZCLA regla e historia en el
   mismo párrafo, NO es candidata — cortar rompería la regla y reescribir está prohibido.
4. **Obsoleto ≠ candidata**: lo que parece muerto (fechas superadas, referencias a cosas
   eliminadas) se REPORTA aparte al usuario, nunca se corta ni borra en esta skill.
5. **Presenta la lista con KB estimados por corte y espera el OK explícito** antes de
   cortar nada. "Sin candidatas" es un veredicto válido — no fuerces hallazgos.

## Fase 2 — Cirugía (solo con OK, archivo por archivo)

1. **Respaldo previo**: copia `.bak-<fecha>` junto a cada original (incluidos los DESTINOS
   existentes que vayas a ampliar — gap real detectado en producción). Al cerrar la
   verificación, los respaldos se archivan en `_archive\`.
2. **El corte lo hace el script, nunca la mano**: `scripts/corte-secciones.py` (probado con
   auto-test integrado). Opera por marcadores substring que deben aparecer EXACTAMENTE una
   vez; si no, aborta ese corte como PENDIENTE en vez de adivinar. Preserva encoding UTF-8
   sin BOM y los fines de línea originales, y trae `verify_coverage()` integrado.
   Corre SIEMPRE su auto-test primero, y si la operación es grande, un dry-run sobre un
   espejo de los archivos antes de tocar los reales.
3. **Anatomía del talón** (los 3 elementos son obligatorios — en producción el único fallo
   del fiscal fue un talón al que le faltaba el tercero):
   - QUÉ contiene lo movido (resumen de una frase, no vacío);
   - RUTA exacta del destino — **verificada contra el disco antes de escribirla** (en
     producción un destino "REVIEW.md" vivía en realidad en `documentos\REVIEW.md`);
   - CUÁNDO leerlo (el trigger concreto).
4. **Destinos**: `auditorias\` para cortes del CLAUDE.md del workspace; la carpeta del
   propio proyecto para archivos de proyectos. Contenido que estaba fuera de tema (p. ej.
   una idea de finanzas dentro de Laboratoria) puede cambiar de proyecto — dilo en el talón.
5. **Registro**: agrega los archivos nuevos a `REFS_INDEX.md` (copia su formato), a la
   sección de archivos relacionados/canónicos del archivo aligerado si la tiene (no la
   inventes si no existe), y actualiza su línea de "Última actualización".

## Fase 3 — Verificación (obligatoria, en este orden)

1. **Cobertura mecánica**: `verify_coverage()` del script — toda línea no vacía del
   original existe textual en el aligerado o en el destino; 0 perdidas, sin duplicados.
2. **Punteros**: grep de referencias a lo movido (por número y por título de sección) en
   CLAUDE.md, memorias, handoffs\ y auditorias\. Las externas deben resolver vía el talón.
   Distingue punteros vivos de menciones históricas en informes viejos (falsos positivos).
3. **Fiscal adversario**: sub-agente FRESCO sin contexto de la conversación, con el prompt
   de `references/verificacion.md`. Umbral: 100% de preguntas respondibles siguiendo solo
   los talones y 0 roturas causadas por la mudanza. Lo que encuentre se corrige y se
   re-verifica. Las roturas PREEXISTENTES que cace de pasada se reportan al usuario como
   lista aparte — corregirlas requiere su OK (suele darlo: son arreglos de rutas).
4. **Git**: si algún archivo tocado vive en un repo (`git status` lo dice), commit + push.

## Advertencias permanentes

- Los cambios a CLAUDE.md no aplican a sesiones abiertas: se releen en sesión nueva o `/clear`.
- El sub-agente fiscal tiene PROHIBIDO leer los `.bak` (invalidaría el test) y todo
  sub-agente hereda las prohibiciones de siempre: sin hijos, sin background, sin bucles.
- Si el trabajo revela que una candidata aprobada no es segura de cortar (regla operativa
  entrelazada), no la cortes ni la reescribas: repórtalo con el porqué y ajusta el alcance.
