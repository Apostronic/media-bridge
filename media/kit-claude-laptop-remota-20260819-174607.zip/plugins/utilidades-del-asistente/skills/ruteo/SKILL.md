---
name: ruteo
description: Mapa de ruteo del kit. Que skill o herramienta usar para cada tarea. Usala cuando no sepas que herramienta aplica, cuando haya overlap entre varias opciones, o cuando el usuario pregunte que skill usar o como rutear una tarea.
---

# Mapa de ruteo — kit base

> Versión inicial del kit. A medida que se instalen más skills, conectores o plugins,
> este mapa se actualiza: cada herramienta nueva se anota aquí con su "cuándo usarla".

## Reglas de prioridad

1. **Antes de ejecutar cualquier tarea**, escanear este mapa y declarar la elección en el sello de tarea (campo Ruteo del CLAUDE.md). "Sin skill aplicable" solo vale DESPUÉS de revisar el mapa.
2. **Tarea compleja de varios pasos** (3+ pasos con dependencias, riesgo real o verificación no trivial) → cargar `metodo-de-trabajo` ANTES de ejecutar, aunque no se vaya a delegar nada.
3. **Al delegar a sub-agentes u orquestar** → además pegar `references/bloque-inyeccion.md` de `metodo-de-trabajo` textual en el prompt de CADA sub-agente, con la línea de dosis según el modelo.
4. **Cuando hay duda real** → releer este mapa; en última instancia, preguntar al usuario con AskUserQuestion antes de activar la herramienta equivocada.

## Mapa

| Tarea | Herramienta |
|---|---|
| Tarea compleja de varios pasos, delegar, orquestar, "aplica el método", rigor extra | `metodo-de-trabajo` |
| Validar un plan o decisión antes de ejecutarla, "hazme las preguntas difíciles" | `grill-me` |
| Configurar un chat nuevo, qué modelo conviene, optimizar tokens | `nuevochat` |
| Respuestas ultra-cortas para ahorrar tokens en tareas simples | `caveman` |
| El CLAUDE.md o los archivos de contexto pesan mucho, mover secciones a bajo-demanda | `optimizar-contexto` |
| Liberar espacio en disco con método seguro | `liberar-espacio` (revisar primero su lista de intocables para ESTA máquina) |
| Loop recurrente o tarea programada | comando `/crear-loop` |
| Navegación web / scraping / automatización de navegador | Playwright MCP (navegador aislado por sesión; ver la sección de navegador del CLAUDE.md) |
| Duda de qué herramienta usar | esta skill |

## Qué NO hay en este kit (todavía)

Generación de imagen/video con IA, skills de marketing/SEO, QA visual instrumentado y
auditoría web integral quedaron fuera de la edición inicial. Si una tarea las pide,
decláralo en el sello ("sin skill aplicable → herramientas base") y avisa al usuario
que esa capacidad se puede sumar al kit.
