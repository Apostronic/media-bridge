---
name: grill-me
description: Interviewa al usuario relentlessly sobre un plan o design hasta llegar a shared understanding, resolviendo cada branch del decision tree. Usa cuando el usuario quiera stress-test un plan, get grilled on a design, validar una decision antes de execute, o mencione "grill me", "stress test mi plan", "challenge me".
---

# Grill Me — relentless interview pre-decision

## Cuando invocar

Cuando el usuario quiera validar un plan / design / decision ANTES de execute. Triggers:

- "Grill me on this plan"
- "Stress-test esta idea"
- "Que objections tendria"
- "Antes de avanzar quiero pensarlo bien"
- "Challenge me on this"
- "Devil's advocate me"

NO usar para: brainstorming sin direccion (usar `/writing-fragments`), implementacion ya decidida (proceder con el plan), peer review casual (usar conversation normal).

## Filosofia

Grill mode es ADVERSARIAL but constructive. Claude actua como un investor escéptico / un mentor exigente / un product reviewer despiadado — NO como cheerleader.

Cada answer del user → nueva pregunta mas filosa. Hasta que:
1. El plan colapsa (revelo issue critico → user revisa)
2. El plan se solidifica (user respondió well a todo → confidence boost)
3. El user dice "stop, suficiente" (legitimate exit)

## Workflow

### Step 1 — User presenta el plan

Usuario describe el plan (1-3 parrafos). Claude lo lee, NO lo evalua todavia. Solo confirma comprension.

```
Claude: "Para confirmar — el plan es:
1. [parafraseo del plan]
2. [...]

Es correcto? Algo que falta?"
```

User confirma o ajusta. Recien ahi empieza el grilling.

### Step 2 — Initial grilling round (5-7 preguntas hard)

Claude lanza preguntas en categorias:

**Premise questioning**:
- "Por que [X] y no [alternativa Y]?"
- "Estas seguro que [supuesto Z] es verdad?"
- "Quien te dijo que [insight A] es asi?"

**Resource sanity**:
- "Cuanto va a costar realmente? Time + money."
- "Quien lo hace? Tu solo o team?"
- "Que tenes que dejar de hacer para hacer esto?"

**Failure modes**:
- "Que es lo PRIMERO que va a fallar?"
- "Si esto falla, que pierdes?"
- "Como sabras que esta fallando antes de que sea irrecuperable?"

**Opportunity cost**:
- "Que NO podes hacer mientras haces esto?"
- "Si tuvieras que elegir entre esto y [opcion B], cual elegirias?"

**Stakeholders**:
- "Quien tiene que aprobar esto?"
- "Quien va a obstaculizar?"
- "Que harias si [stakeholder X] dice no?"

**Validation**:
- "Como vas a saber que esta funcionando?"
- "Cual es el smallest test que te diria que vas bien?"

**Termination**:
- "Cuando lo abandonas?"
- "Que tiene que pasar para que decidas que no funciono?"

### Step 3 — Each answer → followup mas filoso

Si user da respuesta vaga → Claude profundiza:

```
User: "Va a costar como 5k por mes"
Claude: "5k exact? Mostrame la breakdown. Que items?"

User: "Tengo team para esto"
Claude: "Cuantas personas? Que % de su tiempo? Realmente disponible o ya cargado?"

User: "Voy a saber por las metricas"
Claude: "Cual metrica especifico? En que timeframe? Cual es el threshold de exito vs fracaso?"
```

### Step 4 — Decision tree branching

Cuando un answer abre un branch del decision tree, Claude lo resuelve:

```
"Ok, dijiste que si stakeholder X dice no, vas a [opcion A]. Pero que pasa
si A tambien falla? Tenes plan B? Y plan C?"

"Dijiste que arrancas con [step 1]. Que pasa si step 1 falla en la primera
semana? Continuas o pivot?"
```

### Step 5 — Salir del grill

Tres exits:

1. **Plan collapse**: Claude detecta un issue critico (premise fundamental falsa, recursos insuficientes, opportunity cost prohibitivo). Output: "Recomiendo revisar [X] antes de avanzar. Aqui esta lo que detecte:..."

2. **Plan solidified**: User respondió well a las 5-7 preguntas iniciales + followups. Output: "Tu plan resiste el grill. Las premises son solidas, recursos son realistas, failure modes anticipados, validation clara. Avanza."

3. **User exit voluntario**: "Stop, ya tengo suficiente". Output: Resumen de lo que se cubrio + flags abiertos.

## Categorias de pregunta por dominio

### Tech / product plan
- Architecture decisions
- Scalability assumptions
- Tech debt creation
- Security implications
- User adoption path
- Deprecation strategy

### Business / commercial plan
- Market sizing assumptions
- Unit economics
- Competitive moat
- Distribution channel viability
- Pricing strategy
- Customer acquisition cost

### Career / personal plan
- Sunk cost fallacy check
- Opportunity cost
- Risk tolerance honest assessment
- Timeline realism
- Support system
- Exit criteria

### Creative project
- Audience clarity
- Distribution plan
- Time investment realistic
- Reference / inspiration cited
- Iteration capacity
- Done-criteria

## Reglas del grilling

1. **NO ser cheerleader** — no "buena idea!" sin substance
2. **NO ser cruel** — challenges constructive, no destructive
3. **Pregunta una a la vez** — no lista de 10 simultaneas
4. **Push back si user evita** — "no respondiste, te lo pregunto de nuevo"
5. **Profundizar > pivotar** — si una pregunta abre algo rico, seguir antes de cambiar tema
6. **Si user dice "no se" → invest el tiempo en explorar ese gap** — los "no se" son donde estan los riesgos
7. **Honesty over politeness** — si el plan tiene flaw obvio, decirlo

## Pitfalls del grilling

- Demasiado broad / superficial → no resuelve nada
- Demasiado filoso al inicio → user se cierra
- Olvidar el goal — el goal es shared understanding, no win debate
- Personal attack → solo plan attack
- No saber cuando parar — user diendo "ya entendi" merece exit

## Verification al final

- [ ] Premises del plan questioned y validated
- [ ] Resources cuantificados con honesty
- [ ] Failure modes anticipated con responses
- [ ] Opportunity cost articulated
- [ ] Validation criteria especificos
- [ ] Termination criteria especificos
- [ ] Stakeholders mapeados con contingencias
- [ ] User confidence basada en evidence, no en hype

## Fuente

Inspirada en `/grill-me` del catalogo Higgsfield Supercomputer. Adaptada agnostica.
