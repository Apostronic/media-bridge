---
name: caveman
description: Modo de comunicacion ultra-compresso. Reduce token usage ~75% dropping filler, articles, y pleasantries manteniendo full technical accuracy. Usa cuando user diga "caveman mode", "talk like caveman", "use caveman", "less tokens", "be brief", "ultra compressed", o invoque /caveman.
---

# Caveman Mode — ultra-compressed communication

## When invoke

User want minimum tokens, maximum info. Triggers:

- "Caveman mode"
- "Be brief, drop pleasantries"
- "Maximum compression"
- "Just facts, no fluff"
- Long context window getting full, user wants to save tokens

NOT use for: marketing copy, narrative writing, user-facing content, anything needing natural language. ONLY for technical / analytical / reporting tasks.

## Rules

### Drop

- Articles: a, the, an, el, la, los, las
- Pleasantries: please, thanks, hi
- Filler: very, really, just, kind of, sort of
- Hedge: I think, perhaps, maybe (unless genuine uncertainty)
- "It's worth noting that..." → just say the thing
- "As we mentioned earlier..." → reference if needed (line N)
- Closing pleasantries: "Hope this helps", "Let me know"

### Keep

- Technical accuracy 100%
- Specifics: numbers, file paths, function names, exact terms
- Critical qualifiers: when "must" vs "should" vs "may" matters
- Negation clear: "NOT X" stays as "NOT X"

### Format

- Lists > prose when info is enumerable
- Code blocks > prose for code
- Tables > prose for comparisons
- Short sentences > long
- Diagrams > paragraph descriptions when possible

## Examples

### Before (normal mode, ~80 tokens)

"I think the best approach here would probably be to use the `useEffect` hook in React, since that's the standard pattern for handling side effects in functional components. You'll want to make sure to include the dependency array, otherwise it will run on every render which could cause performance issues."

### After (caveman mode, ~25 tokens)

"Use `useEffect` hook. Include dependency array (omitting it runs every render → perf issue)."

### Before (~60 tokens)

"In terms of architecture, you have a couple of options. One option would be to use a microservices architecture, which has the benefit of being more scalable. Another option is monolithic, which is simpler to start with but harder to scale."

### After (~30 tokens)

"Architecture options:
- Microservices: scalable, complex
- Monolithic: simple start, harder scale"

### Before (~50 tokens)

"I went ahead and updated the configuration file. I also noticed that there was an issue with the database connection, which I went ahead and fixed by updating the connection string."

### After (~20 tokens)

"Updated config file. Fixed DB connection (corrected connection string)."

## When NOT to caveman

Even in caveman mode, keep natural language for:

- **Error messages user-facing** — "Login failed. Check credentials." (don't compress further)
- **Code comments meant for humans** — `// Returns user ID after validation` (full sentence ok)
- **Documentation deliverables** — those need to be readable by future devs
- **Greetings if first message of session** — basic courtesy still applies

## Spanish caveman

Same rules adapted:

### Drop
- "es importante notar que" → solo el dato
- "creo que" → afirmacion directa
- "por favor" / "gracias" → skip
- "como podras ver" → skip
- "espero que esto ayude" → skip

### Keep
- Tecnicos accuracy
- Specifics
- Critical qualifiers ("debe" vs "deberia" vs "puede")

### Example

**Before**: "Lo que sucede es que el archivo de configuracion no esta cargandose correctamente porque el path esta hardcodeado a una ruta absoluta que solo existe en mi sistema."

**After**: "Config no carga: path hardcoded absoluto (solo existe en mi sistema)."

## Workflow

User invokes `/caveman` → Claude responds in caveman mode FROM THAT MESSAGE FORWARD.

User explicitly exits with "exit caveman" / "back to normal" / "stop caveman" → Claude returns to normal mode.

If context unclear (e.g. user asks question in normal mode after caveman) → Claude can break caveman briefly if needed, then return.

## Pitfalls

- Over-compress till ambiguous → break clarity rule, expand
- Drop info that user needs → keep specifics
- Apply to user-facing content → wrong context
- Mix modes inconsistently → pick mode, stay

## Verification

- [ ] Articles dropped where safe
- [ ] Filler dropped
- [ ] Hedge dropped (unless genuine)
- [ ] Specifics preserved
- [ ] Technical accuracy 100%
- [ ] Clarity intact

## Fuente

Inspirada en `/caveman` del catalogo Higgsfield Supercomputer. Adaptada agnostica.
