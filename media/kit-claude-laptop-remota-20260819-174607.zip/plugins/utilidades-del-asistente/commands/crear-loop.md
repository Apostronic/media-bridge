---
description: Arma un loop de Claude Code a medida — te entrevista y devuelve la línea exacta de /loop, /goal o /schedule lista para pegar
argument-hint: [opcional: describe lo que quieres automatizar, ej. "vigilar el deploy" | "resumen de correos cada 30m"]
---

Objetivo: ayudar al usuario a armar un loop puntual y bien afinado. Entrevistarlo con las preguntas mínimas, elegir el comando y modo correctos según la ficha verificada de abajo, y devolver la línea EXACTA lista para copiar. Sin prosa extra.

**Vía rápida:** si `$ARGUMENTS` ya describe la necesidad (ej. `/crear-loop vigilar el deploy`, `/crear-loop resumen de correos cada 30m`), úsalo para pre-rellenar: deduce el tipo, el intervalo si lo menciona y la tarea. Pregunta SOLO lo que falte. Si está todo claro, salta directo al Paso 2.

## Paso 0 — ¿Es realmente un loop? (gancho ultracode)

Antes de armar nada, distingue el EJE de la necesidad. Loop y workflow resuelven cosas opuestas:

- **Repetir o vigilar en el tiempo** ("cada X", "hasta que pase Y", "apenas cambie Z") → sí es un loop. Sigue al Paso 1.
- **Una sola tarea pesada y bien hecha** ("audita a fondo", "migra todo esto", "revisa sin que se escape nada", "hazlo y que otro lo verifique") → eso NO es un loop, es un **workflow / ultracode** (una sola corrida que reparte el trabajo en varios agentes que se auditan entre sí). No le armes un loop: dile que para eso escriba `ultracode` o "usa un workflow" en su mensaje, o `/effort ultracode` para toda la sesión. Ver la ficha de workflows al final. Solo si además quiere que eso se REPITA en el tiempo, se combinan (un loop que en cada vuelta corre con ultracode).

## Paso 1 — Entrevista (AskUserQuestion, solo las que falten)

Lanza las preguntas que no estén ya respondidas por `$ARGUMENTS`:

**P1 (header "Necesidad")** — ¿Qué necesitas?
- Revisar algo cada cierto tiempo — web, correo, precios, PRs, noticias *(→ /loop intervalo fijo)*
- Vigilar y reaccionar apenas cambie — deploy, build, CI, un log, un archivo *(→ /loop dinámico, puede usar Monitor)*
- Trabajar sin parar hasta lograr una meta — tests en verde, juntar 100 datos, artículo con N fuentes *(→ /goal o dinámico con meta)*
- Que corra aunque apague la computadora *(→ /schedule, nube)*

**P2 (header "Frecuencia")** — solo si el caso es "revisar cada cierto tiempo":
- Pocos minutos (5m / 10m)
- Media hora u hora (30m / 1h)
- Varias horas (2h / 4h)
- Una vez al día (1d)

**P3 (header "Aviso")** — ¿Cuándo te aviso?
- Solo si hay algo que necesite tu atención
- Siempre, con un resumen corto de cada vuelta

Si el tipo es "meta", además pídele en texto la meta y ayúdalo a volverla **medible** (un número o lista que Claude pueda contar y verificar solo).

## Paso 2 — Lógica de decisión (usa la ficha verificada)

Mapea la necesidad al comando correcto:

- **Revisar periódico** → `/loop <intervalo> <tarea>`. Intervalo limpio (5m, 10m, 15m, 30m, 1h, 2h, 4h, 1d). Mínimo 1 min. Si la hora exacta importa, advierte el jitter (puede dispararse hasta 30 min después).
- **Vigilar y reaccionar** → forma dinámica `/loop <tarea de vigilancia>` (sin intervalo). Explica en 1 línea que para vigilancia es mejor que un intervalo fijo, porque Claude puede *escuchar* con la herramienta Monitor (avisa apenas pasa algo) en vez de preguntar cada X minutos: más rápido y gasta menos.
- **Meta concreta** → recomienda `/goal <condición medible>` (trabaja turno tras turno hasta cumplirla; un modelo rápido revisa después de cada turno). Alternativa equivalente en intervalo: `/loop <tarea> y no pares hasta que <meta medible>`. NUNCA uses la sintaxis `/loop ... until:` (no existe). Si la meta era vaga, ofrece 2 versiones: una estricta y una relajada.
- **Compu apagada** → recomienda `/schedule` (corre en la nube de Anthropic). Avisa los requisitos: plan Pro/Max/Team/Enterprise, mínimo 1 hora, y que los archivos salen de una copia limpia del repo en GitHub (no toca tus archivos locales). Si la tarea necesita archivos locales o un intervalo menor a 1 hora, dile que en la nube no se puede y que la opción es `/loop` con la sesión abierta.

Reglas transversales:
- Si la tarea toca correo, Drive, Calendar u otro servicio externo → avisa que requiere el conector correspondiente conectado.
- Incorpora la preferencia de aviso en la redacción de la tarea ("…y avísame solo si algo necesita tu atención" vs "…y dame un resumen corto").
- La tarea va en español natural; el intervalo se escribe como token con unidad (10m, 2h), independiente del idioma.

## Paso 3 — Devuelve solo este bloque (español neutro LATAM, listo para pegar)

**Comando:**
```
<la línea exacta lista para copiar>
```
**Modo:** [intervalo fijo / dinámico / goal / schedule] — [por qué, ≤12 palabras]
**Variante** (solo si es meta): estricta `…` · relajada `…`
**Recuerda:** [2-3 bullets que apliquen del set: expira a 7 días, recréalo si lo necesitas más tiempo · corre con la sesión abierta · frénalo con Esc durante la pausa · requiere el conector X · requisitos de nube si es /schedule]

---

## Ficha verificada (referencia interna — no la pegues entera; úsala para decidir)

> Contrastado contra la doc oficial de Anthropic (code.claude.com/docs) en junio 2026; re-auditado íntegro el 2026-07-07. Profundidad completa (fichas, recetas, features adyacentes): `auditorias/GUIA-MAESTRA-AUTOMATIZACION-CLAUDE-CODE.md`.

- **`/loop`** corre LOCAL, dentro de la sesión abierta. Mínimo 1 minuto. Máximo 50 tareas por sesión. Expira a los **7 días** (se recrea). Sin catch-up por vuelta: si la hora pasa con Claude ocupado, dispara UNA sola vez al quedar libre (no una por intervalo perdido). Se frena con **Esc** mientras espera la siguiente vuelta; OJO: las tareas pedidas en lenguaje natural NO se frenan con Esc — se borran pidiéndolo.
- Puedes pasar una skill como prompt (`/loop 20m /review-pr 1234`). 🚨 Desde v2.1.196 el disparo programado solo ejecuta skills auto-invocables: comandos built-in (`/model`, `/clear`…), skills bloqueadas (`disable-model-invocation: true`, deny) y MCP prompts llegan como TEXTO PLANO, no corren.
- Unidades `s/m/h/d`. Los segundos se redondean **hacia arriba** al minuto. Intervalos no limpios (7m, 90m) se ajustan al cron más cercano y Claude te dice cuál eligió.
- **Modo dinámico** (sin intervalo): Claude elige el ritmo entre 1 min y 1 h, imprime el tiempo y la razón, y se detiene solo al cumplir la meta. Para vigilancia puede usar la herramienta **Monitor** (escucha en background y avisa al instante; más eficiente que repetir un prompt).
- **Modo mantenimiento** (sin tarea): corre una rutina incorporada o tu `loop.md` si existe. Se busca en `.claude/loop.md` (proyecto, manda) y `~/.claude/loop.md` (usuario).
- **`/proactive`** es alias idéntico de `/loop`.
- **`/goal <condición>`**: mantiene a Claude trabajando turno tras turno hasta cumplir la condición (NO por intervalo). Condición de máx **4.000 caracteres**; UNA meta por sesión (la nueva reemplaza a la activa); `/goal` sin argumento muestra el estado; `/goal clear` la apaga (alias: stop/off/reset/cancel). El juez es un modelo chico (default Haiku) que NO ejecuta herramientas: solo cree lo MOSTRADO en el chat — exige evidencia visible en la condición. Sin tope automático de turnos: mételo en la condición ("…o detente tras 20 turnos"). Es el camino correcto para "no pares hasta lograr X". La sintaxis `/loop … until:` que circula en blogs NO existe.
- **`/schedule`** (Routines, nube): corre aunque apagues la computadora. Requiere plan Pro/Max/Team/Enterprise; mínimo 1 hora; sin expiración; los archivos vienen de copia limpia del repo GitHub; se dispara por horario, API o eventos de GitHub.
- **Jitter:** las tareas recurrentes pueden dispararse hasta 30 min después de la hora marcada (no sirve para precisión de minuto exacto). Para más precisión, elige un minuto que no sea `:00` ni `:30`.
- **Meta medible:** una meta termina cuando se cumple. Convierte lo vago en número o lista contable (ej. "10 competidores, cada uno con precio, plan y link").
- Salvedad: en Bedrock/Vertex/Foundry, `/loop` sin intervalo corre fijo cada 10 min y no lee `loop.md`.

Reglas: español neutro LATAM con tuteo estricto, sin voseo. Sin prosa de relleno. No inventes flags ni sintaxis. Si el usuario ya dio toda la info en `$ARGUMENTS`, no repreguntes: entrega el bloque directo.

---

## Ficha workflows / ultracode (para el gancho del Paso 0 — verificada jun 2026)

> Otro eje, distinto al loop: el loop REPITE en el tiempo; el workflow hace UNA cosa difícil a fondo, en una sola corrida, con varios agentes que se auditan entre sí. Contrastado contra code.claude.com/docs/en/workflows y el blog oficial de Anthropic (24-jun-2026, con verificación adversaria). No es lo que arma este comando: el gancho solo deriva hacia aquí.

- **Qué es:** Claude escribe un script que reparte la tarea entre subagentes (cada uno con su propia ventana). Unos hacen el trabajo; otros frescos intentan refutarlo antes de mostrártelo. Arregla las 3 fallas de un solo chat que Anthropic documentó: pereza (entrega a medias como si estuviera listo), sesgo de auto-aprobación (confía en lo que él mismo escribió) y deriva (pierde el objetivo tras muchas vueltas).
- **Cómo se activa (3 formas, textuales en la doc):** (1) pedirlo con palabras ("usa un workflow"); (2) la palabra clave `ultracode` en el mensaje (1 sola tarea); (3) `/effort ultracode` para toda la sesión (Claude decide solo cuándo armar workflow). `ultracode` = máximo esfuerzo de razonamiento (xhigh) + orquestación automática.
- **Cuándo SÍ:** el costo de un error es alto, la tarea es grande o cruza muchas piezas, quieres doble revisión. Migraciones, auditorías, research a fondo.
- **Cuándo NO:** tareas rutinarias o chicas. Quema MUCHOS más tokens; para lo cotidiano es desperdicio. Vuelve a `/effort high` al terminar lo pesado.
- **Límites reales:** hasta 16 agentes en paralelo y 1.000 por corrida (son topes del sistema, NO suben por pagar un plan más caro). Requiere Claude Code v2.1.154+. Disponible en planes de pago; en Pro NO viene activo (se enciende en `/config`, fila "Dynamic workflows") — en Max sí. Antes de ejecutar te muestra el plan de fases y apruebas una vez. Tamaño acotable con el setting "Dynamic workflow size" de `/config` (small/medium/large, v2.1.202+). Un workflow que funcionó se guarda con la tecla `s` en `/workflows` y queda como comando `/<nombre>`.
- **Estado:** ya es de disponibilidad general (dejó de ser research preview). Caso de prueba real verificado: el creador de Bun lo portó de Zig a Rust (~750.000 líneas, 99,8% de los tests pasando) con cientos de agentes y dos revisores por archivo.
- **No confundir con loop:** loop = repetir o vigilar en el tiempo (`/loop`, `/goal`, `/schedule`). workflow/ultracode = profundidad en una sola corrida. Se pueden combinar.

---

## Loops que verifican su propio trabajo (anti-pereza) — patrón obligatorio

Si la necesidad es un `/goal` (o loop) que además de hacer un cambio AUDITA/verifica su propio resultado sobre muchos ítems (páginas, archivos, pantallas, registros), avísale al usuario y arma el loop con este patrón, porque un solo Claude que hace y revisa se vuelve perezoso y se auto-aprueba (verificado 24-jun-2026):

- **Verificar lo hacen agentes FRESCOS** (el que revisa nunca es el que hizo el cambio) + una pasada ADVERSARIA que arranca de "hay un defecto, demuéstrame que está limpio". El loop nunca se auto-certifica.
- **El verificador de `/goal` solo cree lo que se MUESTRA** en el chat → la condición de cierre debe ser evidencia que genera un script (matriz de cobertura N×criterios + un JSON sin FAIL), no una frase "todo limpio". Las certificaciones heredadas NO cuentan; los criterios subjetivos ("se ve bien") necesitan umbral medible.
- **Paraleliza la verificación** (solo lectura), **serializa la edición** del recurso compartido (sitio/archivo en vivo = campo único; en paralelo se pisa).
- **Loop sano:** define "vuelta" medible, no cuentes reintentos de infra como progreso, ata el freno a N/total (no a "30 iteraciones"), pausa sin colgarte (marca el ítem PENDIENTE y seguí con lo independiente), y detecta oscilación (mismo ítem corregido 3 veces → para y escala).

Ejemplo real destilado en este patrón: `proyectos/mowi/web-paginas-internas/PROMPT-goal-qa-responsive-98estados.md`. Mecánica de workflows/ultracode: memoria `reference_workflows_ultracode_claude_code` (en Code se recuerda sola).
