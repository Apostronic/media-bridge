# sync-plugins.ps1 — propaga los plugins locales de la fuente a la app.
#
# POR QUE EXISTE: hay dos copias de cada plugin y no se sincronizan solas.
#   1) FUENTE : <workspace>\plugins\<x>\   <- aqui se edita SIEMPRE
#   2) App    : ~\.claude\plugins\cache\kit-mowi-skills\<x>\<version>\  (fotocopia)
# Si se edita la fuente sin propagar, la app sigue sirviendo la version vieja SIN AVISAR.
#
# USO:  pwsh -File setup\sync-plugins.ps1            (todos)
#       pwsh -File setup\sync-plugins.ps1 -Plugin utilidades-del-asistente
# Requiere: haber subido "version" en .claude-plugin\plugin.json si cambio el contenido.

param([string]$Plugin = "")

$ErrorActionPreference = "Stop"
$SRC = Join-Path (Split-Path $PSScriptRoot -Parent) "plugins"
if (-not (Test-Path $SRC)) { $SRC = Join-Path $PSScriptRoot "..\plugins" }

$plugins = if ($Plugin) { @($Plugin) } else {
  Get-ChildItem $SRC -Directory | Where-Object { Test-Path (Join-Path $_.FullName ".claude-plugin\plugin.json") } | ForEach-Object { $_.Name }
}

Write-Output "== 1) Refrescando el catalogo local =="
claude plugin marketplace update kit-mowi-skills | Select-Object -Last 1

Write-Output "`n== 2) Actualizando en la app =="
foreach ($p in $plugins) {
  $out = claude plugin update "$p@kit-mowi-skills" 2>&1 | Select-Object -Last 1
  Write-Output "   $p : $out"
}

Write-Output "`n== 3) VERIFICACION (efecto, no comando) =="
foreach ($p in $plugins) {
  $vSrc = (Get-Content (Join-Path $SRC "$p\.claude-plugin\plugin.json") -Raw | ConvertFrom-Json).version
  $cache = "$env:USERPROFILE\.claude\plugins\cache\kit-mowi-skills\$p\$vSrc"
  $estado = if (Test-Path $cache) { "OK" } else { "REVISAR" }
  Write-Output ("   {0,-26} fuente={1,-8} -> {2}" -f $p, $vSrc, $estado)
}
