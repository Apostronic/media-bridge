// Valida que un navegador AISLADO (como el que usa cada chat) nazca logueado en un sitio.
// Uso: node verificar-aislado.js https://sitio-que-exige-login.com [otra-url ...]
// headless:false a proposito — algunos sitios (p. ej. Mailchimp) sirven la pantalla de
// login a los navegadores ocultos aunque las cookies sean validas (falso negativo).
const { chromium } = require('playwright-core');
const STATE = process.env.LOCALAPPDATA + '\\ms-playwright\\storage-state.json';

const urls = process.argv.slice(2);
if (!urls.length) {
  console.log('Uso: node verificar-aislado.js <url> [url2 ...]');
  process.exit(1);
}

(async () => {
  const browser = await chromium.launch({ channel: 'chrome', headless: false });
  const ctx = await browser.newContext({ storageState: STATE });
  const page = await ctx.newPage();
  for (const url of urls) {
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
      await page.waitForTimeout(7000);
      const u = page.url();
      const fuera = /login|signin|sign-in|auth\.|accounts\./i.test(u);
      console.log(url + ' -> ' + (fuera ? 'PARECE DESLOGUEADO' : 'PARECE LOGUEADO') + ' | url final: ' + u.slice(0, 90));
    } catch (e) {
      console.log(url + ' -> ERROR ' + e.message.split('\n')[0]);
    }
  }
  await browser.close();
})();
