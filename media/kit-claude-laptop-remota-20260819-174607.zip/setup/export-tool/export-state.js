// Exporta cookies + localStorage del perfil maestro a storage-state.json.
// El archivo de salida contiene credenciales de sesion: vive SOLO en
// %LOCALAPPDATA%\ms-playwright\, nunca en el workspace ni en un repositorio.
const { chromium } = require('playwright-core');
const BASE = process.env.LOCALAPPDATA + '\\ms-playwright';
const PROFILE = BASE + '\\perfil-maestro';
const OUT = BASE + '\\storage-state.json';

// Sitios cuya sesion vive en localStorage (no solo cookies): agregarlos aqui para que
// la exportacion los visite y capture su almacenamiento. Ejemplo: 'https://app.metricool.com/'
const ORIGENES_LOCALSTORAGE = [];

(async () => {
  let ctx;
  try {
    // headless:false a proposito — en modo oculto Chrome puede no exponer las cookies
    // del perfil y la exportacion sale vacia (verificado 2026-08-19).
    ctx = await chromium.launchPersistentContext(PROFILE, { channel: 'chrome', headless: false });
  } catch (e) {
    console.log('ERROR_PERFIL_OCUPADO_O_INACCESIBLE: ' + e.message.split('\n')[0]);
    process.exit(2);
  }
  const page = ctx.pages()[0] || await ctx.newPage();
  for (const url of ORIGENES_LOCALSTORAGE) {
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 45000 });
      await page.waitForTimeout(8000);
      console.log('VISITADO para localStorage: ' + url);
    } catch (e) { console.log('NO VISITADO ' + url + ': ' + e.message.split('\n')[0]); }
  }
  const state = await ctx.storageState({ path: OUT });
  const dominios = [...new Set(state.cookies.map(c => c.domain.replace(/^\./, '').split('.').slice(-2).join('.')))];
  console.log('EXPORTADO: ' + state.cookies.length + ' cookies, ' + state.origins.length + ' origenes');
  console.log('DOMINIOS: ' + dominios.sort().join(', '));
  await ctx.close();
  process.exit(0);
})();
