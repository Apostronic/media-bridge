@echo off
rem Abre el perfil MAESTRO de Playwright en Chrome, para hacer o renovar logins A MANO
rem (el usuario teclea; Claude nunca maneja credenciales).
rem Despues de loguear: cerrar Chrome por completo y correr setup\exportar-estado-playwright.ps1
set CHROME=C:\Program Files\Google\Chrome\Application\chrome.exe
if not exist "%CHROME%" set CHROME=C:\Program Files (x86)\Google\Chrome\Application\chrome.exe
if not exist "%CHROME%" (
  echo No se encontro Google Chrome. Instalalo o edita este archivo con su ruta.
  pause
  exit /b 1
)
start "" "%CHROME%" --user-data-dir="%LOCALAPPDATA%\ms-playwright\perfil-maestro" %*
