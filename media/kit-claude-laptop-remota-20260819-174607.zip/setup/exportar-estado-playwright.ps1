# exportar-estado-playwright.ps1 — re-exporta los logins del perfil maestro al archivo
# de estado que usan los navegadores aislados de cada chat.
# Uso: pwsh -File setup\exportar-estado-playwright.ps1
# Requisito: el perfil maestro debe estar LIBRE (ningun Chrome corriendo con perfil-maestro).
# El archivo de salida contiene credenciales de sesion: vive en %LOCALAPPDATA%\ms-playwright\,
# NUNCA en el workspace ni en un repositorio.

$ErrorActionPreference = "Stop"
$tool = "$env:LOCALAPPDATA\ms-playwright\export-tool"
$salida = "$env:LOCALAPPDATA\ms-playwright\storage-state.json"

$ocupado = Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" |
  Where-Object { $_.CommandLine -like "*perfil-maestro*" }
if ($ocupado) {
  Write-Output "PERFIL OCUPADO: hay $($ocupado.Count) procesos de Chrome usando el perfil maestro."
  Write-Output "Cierra ese Chrome (o espera a que termine) y reintenta."
  exit 2
}

Set-Location $tool
node export-state.js
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if (Test-Path $salida) {
  $info = Get-Item $salida
  Write-Output "VERIFICADO: $salida ($([math]::Round($info.Length/1KB)) KB, $($info.LastWriteTime))"
} else {
  Write-Output "FALLO: el archivo de estado no se creo."
  exit 1
}
