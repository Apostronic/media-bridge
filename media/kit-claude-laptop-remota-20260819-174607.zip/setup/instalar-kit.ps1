# instalar-kit.ps1 — instala el kit base de Claude en esta computadora.
# Uso:  pwsh -File setup\instalar-kit.ps1                (workspace por defecto)
#       pwsh -File setup\instalar-kit.ps1 -Workspace "C:\ruta\a\tu\workspace"
# Requisitos previos: app de Claude (con Code), Node.js y Google Chrome instalados.

param([string]$Workspace = "$env:USERPROFILE\Documents\Claude")

$ErrorActionPreference = "Stop"
$kit = Split-Path $PSScriptRoot -Parent

Write-Output "== Kit base de Claude — instalacion =="
Write-Output "Workspace destino: $Workspace"

# 1) Workspace y CLAUDE.md
New-Item -ItemType Directory -Force $Workspace | Out-Null
if (Test-Path "$Workspace\CLAUDE.md") {
  Write-Output "AVISO: ya existe un CLAUDE.md en el workspace — NO se sobrescribe. El del kit queda en $Workspace\CLAUDE.kit.md para que compares."
  Copy-Item "$kit\workspace\CLAUDE.md" "$Workspace\CLAUDE.kit.md" -Force
} else {
  Copy-Item "$kit\workspace\CLAUDE.md" "$Workspace\CLAUDE.md"
}

# 2) Plugins (fuente) y setup
robocopy "$kit\plugins" "$Workspace\plugins" /E /NFL /NDL /NJH /NJS | Out-Null
robocopy "$kit\setup" "$Workspace\setup" /E /NFL /NDL /NJH /NJS | Out-Null

# 3) Configuracion de Playwright aislado (.mcp.json del workspace)
$state = "$env:LOCALAPPDATA\ms-playwright\storage-state.json"
$mcp = @{ mcpServers = @{ playwright = @{ command = "npx"; args = @(
  "@playwright/mcp@latest", "--browser", "chrome", "--isolated",
  "--storage-state", $state, "--allow-unrestricted-file-access") } } } | ConvertTo-Json -Depth 6
[System.IO.File]::WriteAllText("$Workspace\.mcp.json", $mcp, [System.Text.UTF8Encoding]::new($false))

# 4) Archivo de estado vacio (se llena con exportar-estado-playwright.ps1 tras loguear)
New-Item -ItemType Directory -Force "$env:LOCALAPPDATA\ms-playwright" | Out-Null
if (-not (Test-Path $state)) {
  [System.IO.File]::WriteAllText($state, '{"cookies":[],"origins":[]}', [System.Text.UTF8Encoding]::new($false))
}

# 5) Herramienta de exportacion de logins
$tool = "$env:LOCALAPPDATA\ms-playwright\export-tool"
New-Item -ItemType Directory -Force $tool | Out-Null
Copy-Item "$kit\setup\export-tool\*" $tool -Force
Push-Location $tool
npm install --no-audit --no-fund 2>&1 | Select-Object -Last 1
Pop-Location

# 6) Registrar el catalogo local e instalar los plugins
claude plugin marketplace add "$Workspace\plugins" 2>&1 | Select-Object -Last 1
foreach ($p in @("utilidades-del-asistente", "nuevochat")) {
  claude plugin install "$p@kit-mowi-skills" 2>&1 | Select-Object -Last 1
}

# 7) Verificacion del efecto
Write-Output ""
Write-Output "== Verificacion =="
Write-Output "CLAUDE.md: $(Test-Path "$Workspace\CLAUDE.md")"
Write-Output ".mcp.json: $(Test-Path "$Workspace\.mcp.json")"
Write-Output "export-tool: $(Test-Path "$tool\export-state.js")"
$cache = "$env:USERPROFILE\.claude\plugins\cache\kit-mowi-skills"
Write-Output "plugins en cache: $(if (Test-Path $cache) { (Get-ChildItem $cache -Directory).Name -join ', ' } else { 'REVISAR (correr setup\sync-plugins.ps1 o reintentar el paso 6)' })"
Write-Output ""
Write-Output "SIGUIENTES PASOS (a mano):"
Write-Output "1. Abre la app de Claude y trabaja desde la carpeta: $Workspace"
Write-Output "2. Completa la seccion de identidad del CLAUDE.md."
Write-Output "3. Logins del navegador: corre setup\abrir-perfil-maestro-playwright.cmd, inicia sesion en tus sitios, cierra Chrome, y corre setup\exportar-estado-playwright.ps1."
