# Guía: cómo actualizar un plugin o una skill del kit

## El modelo mental

Cada plugin existe **dos veces** en la computadora, y **ninguna copia se actualiza sola**:

| # | Copia | Dónde | Quién la usa |
|---|---|---|---|
| 1 | **FUENTE** | `<workspace>\plugins\<plugin>\` | Nadie la lee en vivo; es el original que editas |
| 2 | **Fotocopia** | `~\.claude\plugins\cache\kit-mowi-skills\<plugin>\<version>\` | La app |

Si corriges el original y no vuelves a "fotocopiar", la app sigue leyendo la versión
vieja — y **no avisa**. El síntoma es engañoso: "la skill no responde" o "no existe".

## Procedimiento (3 pasos, en orden)

1. **Editar la FUENTE** — siempre en `<workspace>\plugins\`, nunca la fotocopia.
2. **Subir el número de versión** en `<plugin>\.claude-plugin\plugin.json` (sin este paso
   el sistema asume que no hay nada nuevo y no copia). Arreglo menor → tercer número
   (1.0.0 → 1.0.1); skill nueva o cambio de comportamiento → segundo (1.0.0 → 1.1.0).
3. **Propagar**: `pwsh -File setup\sync-plugins.ps1` (termina con una tabla de
   verificación; si alguna fila dice REVISAR, algo quedó atrás).

El cambio se ve al abrir una sesión nueva.

## Reglas duras

- 🚨 Si la cuenta de Claude es compartida con más gente, **NUNCA subir plugins ni skills
  a la cuenta** (todo lo de la cuenta lo ve cualquiera que entre con ese login). Todo se
  instala local, por carpeta, como hace este kit.
- **Verificar el EFECTO, no el comando**: un "actualizado" no prueba nada — comprobar que
  la carpeta de la versión nueva existe y contiene lo que debe.
- Nunca ponerle a un plugin propio un nombre que empiece con `claude-` (el sistema lo
  rechaza por suplantación de marca).
