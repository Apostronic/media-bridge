# Memoria de trabajo — Dani Bastardo (estación remota "laptop Jorge")

> Archivo de contexto que Claude lee al inicio de cada sesión EN ESTA MÁQUINA: la laptop
> remota del equipo Mowi (conocida como "laptop de Jorge"), operada por Dani a distancia.
> Es la estación secundaria: contiene el núcleo del método de trabajo del workspace
> principal de Dani (agosto 2026), sin sus proyectos ni su contexto de marca.

---

## Identidad del usuario

- **Nombre**: Dani Bastardo (operando esta laptop remota del equipo Mowi)
- **Rol**: gerente de Marketing de Mowi (empleo full-remote)
- **Correo empresa**: reservas@mowiapp.com · **Personal**: daniandresguerra2424@gmail.com
- **GitHub**: Apostronic
- **Estación**: esta es la máquina SECUNDARIA — el workspace principal, los proyectos y
  el contexto de marca viven en la computadora principal de Dani. Ante una tarea que
  requiera ese contexto, decirlo en vez de improvisar.

## 🚨 Regla de idioma (aplica a TODO output)

Español neutro LATAM con **tuteo estricto**. NUNCA voseo.
- Usar: tú / tienes / puedes / quieres / dices / haz / mira / revisa / usa / deja / espera.
- Prohibido: vos / tenés / podés / querés / decís / mirá / fijate / dale / che / anotá / chequeá.
- Vocabulario: "carro" (no auto/coche), "computadora", "celular", "ustedes" (no vosotros).
- **Checklist antes de entregar cualquier archivo**: buscar en el contenido generado con
  `grep -nE "\b(vos|sabés|contame|decime|tenés|podés|querés|decís|armá|anotá|agendá|fijate|mirá|dale|chequeá|verificá|tirá|pegá|esperá|usá)\b"` — si hay coincidencia real (no cita de un tercero), corregir antes de mostrar.
- La regla cubre también lo que producen los sub-agentes: su retorno se revisa antes de integrarlo (el bloque de inyección de `metodo-de-trabajo` ya la incluye).

## Sello de tarea (OBLIGATORIO)

Toda respuesta a un pedido de trabajo (no charla) abre con UNA línea de CUATRO campos,
ANTES de la primera acción:

`Ruteo: [skill/herramienta elegida, o "sin skill aplicable → herramientas base"; cierra SIEMPRE con "método: cargado" o "método: no aplica (tarea simple)"] · Modelo: [el que pide LA TAREA, por nombre, y entre paréntesis el vigente] · Esfuerzo: [el vigente + lo que pide la tarea] · Destino: [carpeta exacta donde caerán los archivos; "n/a" si no crea archivos]`

- Los CUATRO campos salen SIEMPRE, sin condición — no hay caso "alineado = silencio".
- **Campo Ruteo**: sale de escanear el mapa de la skill `ruteo`, no de memoria. Se repite en CADA mensaje que abre o cambia una tarea.
- **Sub-campo método**: "método: cargado" = tarea compleja de varios pasos → se cargó `metodo-de-trabajo` ANTES de ejecutar (y si se delega, el bloque de inyección viaja en cada prompt hijo). "método: no aplica" = tarea simple.
- PROHIBIDO el veredicto vacío ("el actual sirve", "Esfuerzo: OK").

## Campos Modelo y Esfuerzo

Se llenan evaluando CADA pedido; solo RECOMIENDAN — el cambio real lo hace el usuario
desde el desplegable de la app; nunca se le envía un comando para copiar.

- **Modelo — Mecánico** (mover, renombrar, listar, extraer, convertir, clasificar, ejecutar algo ya definido): con MÁS de 10 elementos a procesar uno por uno → delegar DIRECTO a un sub-agente con `model: haiku` (parámetro interno; no cambia tu configuración) y el loop principal solo sintetiza; con 10 o menos → hacerla directo. **Estándar** (la mayoría) → "la tarea pide Sonnet". **Complejo** (diagnóstico enredado, arquitectura, auditoría, migración, decisión de riesgo, síntesis profunda) → "te conviene Opus o Fable".
- **Esfuerzo**: Alto es el piso normal. Para razonamiento profundo de UNA tarea sin enjambre de agentes → recomendar xhigh, o la palabra `ultrathink` dentro del mensaje para un solo turno difícil. Ultracode (workflows multiagente automáticos) solo para auditorías/migraciones/barridos masivos — consume mucho.
- **Pregunta obligatoria**: si el modelo o esfuerzo recomendado difiere del vigente, preguntar con AskUserQuestion ANTES de ejecutar, con dos opciones: "Ya cambié de modelo/esfuerzo" (→ ejecutar de inmediato) y "Seguir con el mismo" (→ ejecutar de inmediato). Anti-fastidio: si el usuario ya respondió al MISMO desajuste en esta sesión, no re-preguntar.

## 🚨 Director de orquesta (solo si la sesión corre en Fable)

Fable DIRIGE y no ejecuta el trabajo pesado: todo lo que pueda hacer un modelo capaz más
barato se delega (sub-agente `sonnet` para análisis/redacción/revisión, `haiku` para lo
mecánico). El loop principal en Fable se reserva para: entender el pedido, planear,
orquestar, sintetizar y decidir riesgo. Pregunta obligatoria antes de cada tramo pesado:
¿esto lo puede hacer Sonnet o Haiku? Si sí, se delega.
**Freno inverso para Opus**: Opus tiende a SOBRE-delegar — en sesiones Opus se ejecuta
directo y se delega SOLO por disparadores mecánicos (>10 elementos, documentos >50 KB,
UI pesada); Opus se auto-verifica, sin verificadores para tareas chicas.

## Gestión de contexto y economía de tokens

- **Higiene de sesión**: al cambiar de tarea → chat nuevo. Sesión de >2-3 horas o lenta → cerrar y continuar en sesión fresca.
- **Delegación mecánica — 3 disparadores, SIEMPRE sub-agente**: ① bloque de >10 acciones de interfaz, ② navegación web iterativa, ③ lectura de documentos >50 KB. El sub-agente devuelve solo conclusiones.
- **Método de trabajo — DOS disparadores obligatorios**: (a) al arrancar cualquier tarea compleja de varios pasos → cargar el SKILL.md de `metodo-de-trabajo` completo ANTES de ejecutar, aunque no se delegue; (b) al delegar u orquestar → además pegar su `references/bloque-inyeccion.md` textual en el prompt de CADA sub-agente, con la dosis según el modelo. Se declara siempre en el sello.
- **🚨 Los sub-agentes NO paren hijos**: todo prompt de sub-agente prohíbe lanzar sus propios agentes, tareas en segundo plano o bucles de espera. El paralelismo vive solo en el loop principal.
- **Lotes por TAMAÑO** (~300 KB de texto por agente, los archivos grandes van solos) y **tandas de 5-12 agentes** (nunca decenas de golpe).
- **Lectura quirúrgica**: buscar y leer por rango, nunca archivos enteros sin necesidad. No pegar volcados gigantes; resumir.

## Regla anti-anclaje (freno mecánico)

Cuando el mismo enfoque falla 2 veces, NO intentar la variante #3. Antes, llenar esta tabla:

| Premisa que asumo | ¿Puedo EVITAR el problema en vez de manejarlo? | 2 alternativas que descarté implícitamente |
|---|---|---|

- **Bugs de herramientas: reproducir antes de arreglar** — montar el test mínimo que aísle la capa que falla antes del primer arreglo.
- **Verificar el EFECTO, no el comando**: un "listo" del comando no prueba nada. Tras escribir un archivo, confirmar el contenido; tras un cambio, observar el comportamiento nuevo. Lo que no se pudo comprobar se reporta como NO VERIFICADO, jamás se da por bueno.
- Mismo principio para ALERTAR: antes de avisar de un problema, verificar el estado actual — no heredar supuestos de informes anteriores.

## Regla de ejecución autónoma

Ejecutar automáticamente lo solicitado, sin devolverle la tarea al usuario. Solo pedir
intervención humana cuando sea físicamente imposible para Claude: códigos de verificación
(2FA), decisiones de negocio, gasto de dinero, o acciones prohibidas por seguridad. NUNCA
devolver una tarea por comodidad. Patrón: intentar → si hay bloqueo técnico real, reportar
el bloqueo específico → recién entonces pedir ayuda diciendo exactamente qué hacer.

## Entregables limpios de proceso interno

Nada del proceso interno (versiones v1/v2, menciones a auditorías o QA, el sello, nombres
de skills/modelos/prompts, rutas del workspace) aparece en NINGÚN archivo resultante de
una tarea: ni documentos, ni imágenes, ni presentaciones, ni copies — incluido el NOMBRE
del archivo final. Excepción única: documentos internos que se quedan en el workspace.
Ante la mínima duda de si algo es entregable o interno → preguntar antes de escribirlo.

## Anti-secretos

NUNCA escribir claves API, tokens ni credenciales en documentos, scripts, skills ni en
este archivo. Los secretos viven en variables de entorno. Al citar un archivo de
configuración con claves, censurarlas. Si un archivo nuevo necesita una clave, dejar un
marcador y pedir al usuario que la complete.

## Evidencia antes de veredicto (piezas visuales)

Toda pieza visual que se presente lleva antes de cualquier valoración: (1) qué archivo o
captura se abrió y qué se midió; (2) tabla pedido-vs-observado punto por punto con
veredicto PASA/FALLA contra el PEDIDO del usuario (nunca contra el prompt generativo);
(3) PROHIBIDOS los adjetivos de calidad ("excelente", "perfecto") sin evidencia citada.
Lo que no se pudo percibir (movimiento, audio) se declara NO VERIFICADO.

## Navegador — Playwright aislado por sesión

- Playwright MCP es la vía por defecto para navegación, scraping y automatización web.
- Cada sesión lanza su PROPIO navegador efímero (`--isolated` + `--storage-state` en el
  `.mcp.json` del workspace) que nace ya logueado desde el archivo de estado
  `%LOCALAPPDATA%\ms-playwright\storage-state.json`. Las sesiones no comparten navegador.
- **Mantenimiento de logins**: si un sitio aparece deslogueado → abrir el perfil maestro
  con `setup\abrir-perfil-maestro-playwright.cmd` (el usuario teclea el login; Claude
  nunca maneja credenciales) y luego `setup\exportar-estado-playwright.ps1` re-exporta el
  estado. Los navegadores ya abiertos siguen con la foto vieja hasta cerrarse y renavegar.
- 🚨 Playwright JAMÁS se declara en el config de la app (`claude_desktop_config.json`):
  los conectores de ese archivo son UN servidor compartido por todos los chats y producen
  colisiones. Solo en el `.mcp.json` del workspace.
- Dentro de una misma sesión, los sub-agentes comparten el navegador de esa sesión: si
  orquestas tandas paralelas que navegan, cada tanda abre su pestaña propia.

## Reglas de archivo

- NO crear archivos en la raíz del workspace (aquí solo viven los .md de contexto).
- Estructura sugerida: `documentos/` (trabajo en curso e informes), `entregables/` (solo
  versiones finales aprobadas), `setup/` (scripts del sistema), `_archive/` (preferir
  archivar antes que borrar). Ajústala a tu flujo y documenta aquí la definitiva.
- Intermedios y pruebas → carpeta temporal de la sesión (scratchpad), nunca el workspace.
- NO crear documentación .md salvo pedido explícito.

## Plugins locales — regla de las dos copias

Los plugins viven DOS veces: la FUENTE (`<workspace>\plugins\`) y la fotocopia que usa la
app. Si editas la fuente sin subir la versión en `.claude-plugin\plugin.json` y sin correr
`setup\sync-plugins.ps1`, el cambio NO llega y no avisa. Guía completa: `setup\GUIA-PLUGINS.md`.
🚨 Si la cuenta de Claude es compartida con más gente, NUNCA subir plugins ni skills a la
cuenta: todo se instala local, por carpeta.
