# Kit base de Claude — laptop remota (estación "Jorge")

Paquete autocontenido para montar en la laptop remota del equipo Mowi (operada por Dani a
distancia) el método de trabajo probado en su workspace principal: el modo orquestador,
el sello de tarea, las reglas de modelos y esfuerzo, los frenos anti-error y el navegador
automatizado aislado por chat.

**Este kit NO contiene credenciales**: los logins del navegador se hacen a mano en esa
máquina (paso 5 de la instalación) y quedan solo en ella. El archivo de estado de la
computadora principal NUNCA viaja por este repositorio.

## Qué incluye

- **`workspace/CLAUDE.md`** — el "sistema operativo" que Claude lee en cada sesión:
  sello de tarea, recomendación de modelo y esfuerzo por tarea, modo director de orquesta
  (delegación a sub-agentes), freno anti-anclaje, regla de evidencia, ejecución autónoma,
  entregables limpios, anti-secretos y las reglas del navegador.
- **`plugins/`** — dos plugins locales:
  - `utilidades-del-asistente`: metodo-de-trabajo (el manual del orquestador), ruteo,
    grill-me (validación adversarial de planes), caveman (ahorro de tokens),
    optimizar-contexto, liberar-espacio y el comando /crear-loop.
  - `nuevochat`: configura cada chat nuevo (modelo y tokens).
- **`setup/`** — instalador, sincronizador de plugins, guía de mantenimiento y el sistema
  de navegador aislado (Playwright): cada chat navega en su propio navegador, ya logueado
  con tus sesiones, sin chocar con otros chats.

## Requisitos

1. App de Claude para Windows (con la pestaña Code) e inicio de sesión hecho.
2. Node.js (https://nodejs.org, versión LTS).
3. Google Chrome.

## Instalación (10 minutos)

1. Descarga o clona este repositorio en cualquier carpeta.
2. Abre PowerShell en esa carpeta y corre:
   ```powershell
   pwsh -File setup\instalar-kit.ps1
   ```
   (por defecto crea el workspace en `Documentos\Claude`; puedes pasar otra ruta con
   `-Workspace "C:\otra\ruta"`)
3. Abre la app de Claude y trabaja desde esa carpeta.
4. Completa la sección **Identidad** del `CLAUDE.md` con tus datos.
5. **Logins del navegador** (una sola vez): corre
   `setup\abrir-perfil-maestro-playwright.cmd`, inicia sesión a mano en los sitios que
   Claude vaya a usar por ti, cierra Chrome por completo y corre
   `pwsh -File setup\exportar-estado-playwright.ps1`.
6. Prueba: en un chat nuevo pide "abre <un sitio donde te logueaste> con Playwright y
   dime si estoy logueado".

## Mantenimiento

- **Un sitio pide login de nuevo** → repite el paso 5 (los navegadores de los chats ya
  abiertos siguen con la foto vieja: pídele al chat que cierre su navegador y renavegue).
- **Editar una skill** → `setup\GUIA-PLUGINS.md` (regla de las dos copias).
- **Regla de seguridad**: nunca declares el navegador Playwright en la configuración de
  la app (config global) — solo en el `.mcp.json` del workspace, como deja el instalador.
  El motivo está documentado en el CLAUDE.md.
